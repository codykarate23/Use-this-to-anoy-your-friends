for (var i = 0; i < 1000; i++){
    alert("You have been trolled " + i + " Out of 1000000 Times!")
}